<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Student;
use Illuminate\Support\Facades\DB;

class IndexController extends Controller
{
    public function index(Request $request)
    {

        $tahunLulus = $request->input('tahun_lulus', date('Y')); // Default to current year if no tahun lulus is provided
        $studyProgram = $request->input('program_studi', 'All'); // Default to 'All' if no study program is provided

        $getStatusNow = Student::getStatusNow($tahunLulus, $studyProgram);
        $getWorkBeforeGraduate = Student::getWorkBeforeGraduate($tahunLulus, $studyProgram);

        $graduationYears = Student::select('tahun_lulus')
            ->distinct()
            ->orderBy('tahun_lulus', 'desc')
            ->get()
            ->pluck('tahun_lulus');

        $studyPrograms = Student::select('program_studi')
            ->distinct()
            ->orderBy('program_studi', 'asc')
            ->get()
            ->pluck('program_studi');


        $getMIF = Student::getMIF();
        $getTIF = Student::getTIF();
        $getTKK = Student::getTKK();
        $getStatusNow = Student::getStatusNow($tahunLulus, $studyProgram);
        $getWorkBeforeGraduate = Student::getWorkBeforeGraduate($tahunLulus, $studyProgram);
        $getWorkBeforeGraduateMonth =  Student::getWorkBeforeGraduateMonth($tahunLulus, $studyProgram);
        $getWorkAfterGraduateMonth = Student::getWorkAfterGraduateMonth($tahunLulus, $studyProgram);
        $getSalary = Student::getSalary($tahunLulus, $studyProgram);
        $getWorkingPlaceProvince = Student::getWorkingPlaceProvince($tahunLulus, $studyProgram);
        $getWorkingPlaceRegency = Student::getWorkingPlaceRegency($tahunLulus, $studyProgram);
        $getIfSelfEmployeed = Student::getIfSelfEmployeed($tahunLulus, $studyProgram);
        $getInstanceType = Student::getInstanceType($tahunLulus, $studyProgram);
        $getWorkGrade = Student::getWorkGrade($tahunLulus, $studyProgram);
        $getWorkCorrelation = Student::getWorkCorrelation($tahunLulus, $studyProgram);
        $getWorkGradeAppropriate = Student::getWorkGradeAppropriate($tahunLulus, $studyProgram);
        $getFurtherStudyCost = Student::getFurtherStudyCost($tahunLulus, $studyProgram);
        $getCountFurtherStudy = Student::getCountFurtherStudy($tahunLulus, $studyProgram);
        $getFindWorkBeforeGraduate = Student::getFindWorkBeforeGraduate($tahunLulus, $studyProgram);
        $getFindWorkAfterGraduate = Student::getFindWorkAfterGraduate($tahunLulus, $studyProgram);
        $getGotJobBeforeGraduateAndCorrelated = Student::getGotJobBeforeGraduateAndCorrelated($tahunLulus, $studyProgram);
        // echo json_encode($getWorkBeforeGraduate);
        // die();
        return view('welcome', [
            'getMIF' => $getMIF,
            'getTIF' => $getTIF,
            'getTKK' => $getTKK,
            'getStatusNow' => $getStatusNow,
            'getWorkBeforeGraduate' => $getWorkBeforeGraduate,
            'getWorkBeforeGraduateMonth' => $getWorkBeforeGraduateMonth,
            'getWorkAfterGraduateMonth' => $getWorkAfterGraduateMonth,
            'getSalary' => $getSalary,
            'getWorkingPlaceProvince' => $getWorkingPlaceProvince,
            'getWorkingPlaceRegency' => $getWorkingPlaceRegency,
            'getIfSelfEmployeed' => $getIfSelfEmployeed,
            'getInstanceType' => $getInstanceType,
            'getWorkGrade' => $getWorkGrade,
            'getWorkCorrelation' => $getWorkCorrelation,
            'getWorkGradeAppropriate' => $getWorkGradeAppropriate,
            'getFurtherStudyCost' => $getFurtherStudyCost,
            'getCountFurtherStudy' => $getCountFurtherStudy,
            'getFindWorkBeforeGraduate' => $getFindWorkBeforeGraduate,
            'getFindWorkAfterGraduate' => $getFindWorkAfterGraduate,
            'getGotJobBeforeGraduateAndCorrelated' => $getGotJobBeforeGraduateAndCorrelated,
            'graduationYears' => $graduationYears,
            'studyPrograms' => $studyPrograms,
            'selectedGraduationYear' => $tahunLulus,
            'selectedStudyProgram' => $studyProgram,
        ]);
    }

    public function filterData(Request $request)
    {
        $tahunLulus = $request->input('tahun_lulus');
        $studyProgram = $request->input('program_studi');

        // Fetch all datasets
        $datasets = [
            'status_now' => 'getStatusNow',
            'work_before_graduate' => 'getWorkBeforeGraduate',
            'work_before_graduate_month' => 'getWorkBeforeGraduateMonth',
            'work_after_graduate_month' => 'getWorkAfterGraduateMonth',
            'salary' => 'getSalary',
            'working_place_province' => 'getWorkingPlaceProvince',
            'working_place_regency' => 'getWorkingPlaceRegency',
            'if_self_employed' => 'getIfSelfEmployeed',
            'instance_type' => 'getInstanceType',
            'work_grade' => 'getWorkGrade',
            'work_correlation' => 'getWorkCorrelation',
            'work_grade_appropriate' => 'getWorkGradeAppropriate',
            'further_study_cost' => 'getFurtherStudyCost',
            'count_further_study' => 'getCountFurtherStudy',
            'find_work_before_graduate' => 'getFindWorkBeforeGraduate',
            'find_work_after_graduate' => 'getFindWorkAfterGraduate',
            'got_job_before_graduate_and_correlated' => 'getGotJobBeforeGraduateAndCorrelated',
            // Add more datasets as needed
        ];

        $filteredData = [];

        // Fetch data for each dataset
        foreach ($datasets as $dataType => $method) {
            $filteredData[$dataType] = Student::$method($tahunLulus, $studyProgram);
        }

        return response()->json($filteredData);
    }
}
