document.addEventListener('DOMContentLoaded', function () {
    var ctx = document.getElementById('workBeforeGraduateMonthChart').getContext('2d');
    var workBeforeGraduateMonthChart = null;

    function updateWorkBeforeGraduateMonthChart(data) {
        console.log('Data for chart:', data); // Log the data for debugging

        // Extract the array from the object if necessary
        if (data.work_before_graduate_month && Array.isArray(data.work_before_graduate_month)) {
            data = data.work_before_graduate_month;
        } else if (!Array.isArray(data)) {
            console.error('Expected data to be an array', data);
            return;
        }

        var labels = data.map(function (item) {
            return item.bulan_pekerjaan_sebelum_lulus;
        });
        var counts = data.map(function (item) {
            return item.count;
        });

        if (workBeforeGraduateMonthChart) {
            workBeforeGraduateMonthChart.destroy();
        }

        workBeforeGraduateMonthChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Number of Students',
                    data: counts,
                    backgroundColor: 'rgba(255, 99, 132, 0.2)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    function fetchData(dataType, tahunLulus, studyProgram) {
        fetch(`/filter-data?data_type=${dataType}&tahun_lulus=${tahunLulus}&program_studi=${studyProgram}`)
            .then(response => response.json())
            .then(data => {
                console.log('Fetched data:', data); // Log the fetched data

                switch (dataType) {
                    case 'work_before_graduate_month':
                        updateWorkBeforeGraduateMonthChart(data);
                        break;
                    default:
                        console.log(`Unhandled data type: ${dataType}`);
                }
            })
            .catch(error => {
                console.error('Error fetching data:', error);
            });
    }

    function updateCharts(tahunLulus, studyProgram) {
        fetchData('work_before_graduate_month', tahunLulus, studyProgram);
    }

    document.getElementById('graduation-year-select').addEventListener('change', function () {
        var selectedGraduationYear = this.value;
        var selectedStudyProgram = document.getElementById('study-program-select').value;
        updateCharts(selectedGraduationYear, selectedStudyProgram);
    });

    document.getElementById('study-program-select').addEventListener('change', function () {
        var selectedStudyProgram = this.value;
        var selectedGraduationYear = document.getElementById('graduation-year-select').value;
        updateCharts(selectedGraduationYear, selectedStudyProgram);
    });

    // Initialize chart with initial data
    updateCharts('{{ $selectedGraduationYear }}', '{{ $selectedStudyProgram }}');
});
